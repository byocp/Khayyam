Installation  of samples

To install these sample scripts, simply add this folder to Matlab's path (File Menu->Set Path->Add Folder...).
