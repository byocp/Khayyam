function LucamGUI()
% LucamGUI - Displays the Lumenera Camera graphical interface.
LumeneraGUI;